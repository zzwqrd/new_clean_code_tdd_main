import 'package:dio/src/response.dart';

// class CustomResponse<T> {
//   final bool success;
//   final int statusCode;
//   final T? data;
//   final String msg;
//   final int errType;
//
//   CustomResponse({
//     required this.success,
//     required this.statusCode,
//     this.data,
//     required this.msg,
//     required this.errType,
//     Response? response,
//   });
// }
class CustomResponse<T> {
  final bool success;
  final int statusCode;
  final int errType;
  final String msg;
  final Response? response;

  CustomResponse({
    required this.success,
    required this.statusCode,
    required this.errType,
    required this.msg,
    this.response,
    required data,
  });
}
