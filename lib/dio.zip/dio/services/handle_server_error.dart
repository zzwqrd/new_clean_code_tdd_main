import 'package:dio/dio.dart';

import '../../core/error/handle_error.dart';
import '../../core/utils/app_string.dart';
import 'custom_response.dart';

class HandleServerError {
  static CustomResponse<T> handleDioError<T>(DioException e) {
    String errorMessage;
    int errorType;

    if (e.response?.data is Map &&
        e.response?.data['message'] == AppString.accountSuspended) {
      errorMessage =
          AppString.accountSuspended; // Specific error message in Arabic
      errorType = 1;
    } else {
      if (e.response?.headers.value('content-type')?.contains('text/html') ??
          false) {
        final errorHtml = e.response?.data.toString() ?? 'Unknown HTML error';
        errorMessage = "Error Response (HTML): $errorHtml";
        errorType = 1;
      } else {
        switch (e.type) {
          case DioExceptionType.connectionTimeout:
          case DioExceptionType.sendTimeout:
          case DioExceptionType.receiveTimeout:
            errorMessage = AppString.connectionTimeout;
            errorType = 0;
            break;
          case DioExceptionType.badResponse:
            errorMessage = HandleError()
                .handleError(e.response?.statusCode, e.response?.data);
            errorType = 1;
            break;
          case DioExceptionType.cancel:
            errorMessage = AppString.requestCancelled;
            errorType = 2;
            break;
          case DioExceptionType.connectionError:
            errorMessage = AppString.noInternetConnection;
            errorType = 0;
            break;
          default:
            errorMessage = AppString.unknownError;
            errorType = 2;
        }
      }
    }

    return CustomResponse<T>(
      success: false,
      errType: errorType,
      msg: errorMessage,
      statusCode: e.response?.statusCode ?? 0,
      response: e.response,
      data: null,
    );
  }
}
