class AppString {
  static const String baseUrl = 'https://gorest.co.in/public/v2';
  static const String noInternetConnection = 'No Internet Connection';
}
