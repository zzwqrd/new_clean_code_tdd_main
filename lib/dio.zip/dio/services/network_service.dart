import 'package:dartz/dartz.dart';
import 'package:flutter/foundation.dart';

import 'custom_response.dart';
import 'dio_service.dart';
import 'failures.dart';

abstract class NetworkService {
  final DioService dioHelper = DioService();

  Future<Either<Failure, ReturnType>> exceptionHandler<ReturnType>(
      Future<Either<CustomResponse<ReturnType>, ReturnType>> Function()
          function) async {
    try {
      final result = await function();
      return result.fold(
        (failure) => Left(ServerFailure(
            message: failure.msg, statusCode: failure.statusCode)),
        (data) => Right(data),
      );
    } catch (e, trace) {
      if (kDebugMode) {
        print(e.toString());
        print(trace.toString());
      }
      return Left(ServerFailure(
          message: "Something went wrong, please try again later.",
          statusCode: 500));
    }
  }
}
