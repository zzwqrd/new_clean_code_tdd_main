import 'dart:async';
import 'dart:convert';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';

import '../../core/utils/helpers/loger.dart';
import 'app_string.dart';
import 'base_url_service.dart';
import 'custom_api_interceptor.dart';
import 'custom_response.dart';
import 'handle_error.dart';
import 'handle_server_error.dart';
import 'network_info.dart';

class DioService {
  static final DioService _instance = DioService._internal();
  final Dio _dio;
  final LoggerDebug log;

  late NetworkInfo _networkInfo;
  late HandleServerError _handleServerError;
  // late BaseUrlService _baseUrlService;

  String? BASE_URL;

  DioService._internal()
      : _dio = Dio(),
        log = LoggerDebug(
            headColor: LogColors.red, constTitle: "Server Gate Logger") {
    _dio.interceptors.add(CustomApiInterceptor(log));
  }

  factory DioService() {
    return _instance;
  }

  void initialize(NetworkInfo networkInfo, BaseUrlService baseUrlService) {
    _networkInfo = networkInfo;
    // _baseUrlService = baseUrlService;
    _handleServerError = HandleServerError();
  }

  Map<String, dynamic> _header() {
    return {
      "Accept": "application/json",
      'content-Type': 'application/json',
    };
  }

  Future<Response> _executeRequest({
    required String url,
    dynamic requestBody,
    Map<String, dynamic>? params,
    required Options options,
    required String method,
  }) async {
    final requestUrl = url.startsWith("http") ? url : "$BASE_URL/$url";

    switch (method.toUpperCase()) {
      case 'GET':
        return await _dio.get(requestUrl,
            queryParameters: params, options: options);
      case 'POST':
        return await _dio.post(requestUrl, data: requestBody, options: options);
      case 'PUT':
        return await _dio.put(requestUrl, data: requestBody, options: options);
      case 'DELETE':
        return await _dio.delete(requestUrl,
            data: requestBody, options: options);
      default:
        throw UnsupportedError("Unsupported HTTP method: $method");
    }
  }

  Future<String?> getBaseUrl() async {
    BASE_URL = "https://gorest.co.in/public/v2";
    String? url;
    try {
      if (BASE_URL != null) return BASE_URL;
      final result = await _dio.get(
        url!,
        options: Options(
          headers: {"Accept": "application/json"},
          sendTimeout: const Duration(milliseconds: 5000),
          receiveTimeout: const Duration(milliseconds: 5000),
        ),
      );
      if (result.data != null) {
        BASE_URL = result.data;
        log.red("------Base url -----\x1B[31m$BASE_URL\x1B[0m");
        return BASE_URL;
      } else {
        throw DioException(
          requestOptions: result.requestOptions,
          response: Response(
            requestOptions: result.requestOptions,
            data: {"message": "لم نستتطع الاتصال بالسيرفر"},
          ),
          type: DioExceptionType.badResponse,
        );
      }
    } catch (e) {
      final requestOptions = RequestOptions(path: url!);
      throw DioException(
        requestOptions: requestOptions,
        response: Response(
          requestOptions: requestOptions,
          data: {"message": "حدث خطآ عند الاتصال بالسيرفر"},
        ),
        type: DioExceptionType.badResponse,
      );
    }
  }

  Future<CustomResponse<T>> _sendRequest<T>({
    required String url,
    required String method,
    Map<String, dynamic>? headers,
    Map<String, dynamic>? body,
    Map<String, dynamic>? params,
    T Function(dynamic)? callback,
    bool withoutHeader = false,
  }) async {
    await getBaseUrl();

    if (await Connectivity().checkConnectivity() == ConnectivityResult.none) {
      return CustomResponse<T>(
        success: false,
        errType: 0,
        msg: AppString.noInternetConnection,
        statusCode: 404,
        data: null,
      );
    }

    body?.removeWhere((key, value) => value == null || value == "");
    params?.removeWhere((key, value) => value == null || value == "");

    if (headers == null) {
      headers = _header();
    } else {
      if (!withoutHeader) headers.addAll(_header());
      headers.removeWhere((key, value) => value == null || value == "");
    }

    log.white("Request body: ${jsonEncode(body)}");
    log.white("Request params: ${jsonEncode(params)}");

    dynamic _prepareRequestBody(Map<String, dynamic>? body) {
      if (body != null && body.values.any((value) => value is MultipartFile)) {
        return FormData.fromMap(body);
      } else {
        return jsonEncode(body ?? {});
      }
    }

    try {
      final options = Options(
        headers: withoutHeader ? null : headers,
        contentType:
            body != null && body.values.any((value) => value is MultipartFile)
                ? Headers.formUrlEncodedContentType
                : Headers.jsonContentType,
        responseType: ResponseType.json,
      );

      dynamic requestBody = withoutHeader ? body : _prepareRequestBody(body);

      final response = await _executeRequest(
        url: url,
        requestBody: requestBody,
        params: params,
        options: options,
        method: method,
      );

      log.green(
          "Response: ${jsonEncode(response.data)} (Status code: ${response.statusCode})");

      if (response.statusCode! >= 200 && response.statusCode! < 300) {
        if (response.statusCode == 201) {
          log.green(
              "Resource created at: ${response.headers['Location']?.first ?? ''}");
        }
        return CustomResponse<T>(
          success: true,
          statusCode: response.statusCode!,
          data: callback != null ? callback(response.data) : response.data,
          errType: 0,
          msg: '',
        );
      } else {
        return CustomResponse<T>(
          success: false,
          statusCode: response.statusCode!,
          msg: HandleError().handleError(response.statusCode, response.data),
          errType: 0,
          data: response.data,
        );
      }
    } on DioException catch (e) {
      return HandleServerError.handleDioError<T>(e);
    }
  }

  Future<Either<CustomResponse<T>, T>> getRequest<T>(String endpoint,
      {Map<String, dynamic>? queryParams}) async {
    final baseUrl = await getBaseUrl();
    _dio.options.baseUrl = baseUrl!;
    final response = await _sendRequest<T>(
      url: endpoint,
      method: 'GET',
      params: queryParams,
    );
    return response.success ? Right(response.response!.data) : Left(response);
  }

  Future<Either<CustomResponse<T>, T>> postRequest<T>(
      String endpoint, Map<String, dynamic> data) async {
    final baseUrl = await getBaseUrl();
    _dio.options.baseUrl = baseUrl!;
    final response = await _sendRequest<T>(
      url: endpoint,
      method: 'POST',
      body: data,
    );
    return response.success ? Right(response.response!.data) : Left(response);
  }

  Future<Either<CustomResponse<T>, T>> putRequest<T>(
      String endpoint, Map<String, dynamic> data) async {
    final baseUrl = await getBaseUrl();
    _dio.options.baseUrl = baseUrl!;
    final response = await _sendRequest<T>(
      url: endpoint,
      method: 'PUT',
      body: data,
    );
    return response.success ? Right(response.response!.data) : Left(response);
  }

  Future<Either<CustomResponse<T>, T>> deleteRequest<T>(String endpoint) async {
    final baseUrl = await getBaseUrl();
    _dio.options.baseUrl = baseUrl!;
    final response = await _sendRequest<T>(
      url: endpoint,
      method: 'DELETE',
    );
    return response.success ? Right(response.response!.data) : Left(response);
  }
}

// final Dio _dio;
// final NetworkInfo _networkInfo;
// final LoggerDebug log;
// final String token;
// final BaseUrlService baseUrlService;
//
// DioService._internal(this.log, this._networkInfo, this.token)
//     : _dio = Dio(BaseOptions(
// baseUrl: AppString.baseUrl, // سيتم استبداله عند تشغيل _getBaseUrl
// connectTimeout: Duration(milliseconds: 5000),
// receiveTimeout: Duration(milliseconds: 3000),
// )),
// baseUrlService = BaseUrlService(Dio(), log) {
// _dio.interceptors.add(CustomApiInterceptor(log));
// }
//
// static DioService? _instance;
//
// factory DioService(LoggerDebug log, NetworkInfo networkInfo, String token) {
// return _instance ??= DioService._internal(log, networkInfo, token);
// }
